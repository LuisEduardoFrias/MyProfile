import { P, S, T } from '../js/tools.js';

import { source, Div, Img, Label } from '../js/tools.js';

export default function skill(element, name, url) {

    const div = Div([ 
         Img(source + url, name, ".skill-img", "width: 70%; height: 70%;"), 
         Label(name,".skill-name") 
         ],".skill-container");
    
    div.style.borderBottomColor = `${P}`;
    div.style.borderLeftColor = `${P}`;
    div.style.borderTopColor = `${T}`;
    div.style.borderRightColor = `${T}`;
    
    element.appendChild(div);
    
    return element;
}

