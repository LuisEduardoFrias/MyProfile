/*import { getdata, skills, experiences, proyects, educations, references } from '../data/data_access.js'

import { Select, Label, Div, removeChild } from './tools.js'

import cp_skill from './component_skill.js'
import cp_experience from './component_experience.js'
import cp_proyect from './component_proyect.js'
import cp_education from './component_education.js'
import cp_reference from './component_reference.js'
import cp_profile from './component_profile.js'
*/
export default function unmatches() {

/*
 const btnS = Select(".btnS");
 const btnE = Select(".btnE");
 const btnP = Select(".btnP");
 const btnEd = Select(".btnEd");
 const btnR = Select(".btnR");
 let href;

*//*
 const main = Select(".container-main");

 function skill() {
  
  history.pushState(null, "", "skills");
  
  if(location.href !== href) {
   
   removeChild(main);

   (async () => {

    main.appendChild(Div([], ".skills"));

    await getdata(skills).forEach(i => cp_Skill(Select('.skills'), i.name, i.url));

   })();
   
   href = location.href;
   
  }

 }

 skill();*/

 /* ********************************** */
/*
 btnS.addEventListener("click", (event) => skill());

 /* ********************************** */
/*
 btnE.addEventListener("click", (event) => {
  history.pushState(null, "", "experiences");
  if(location.href !== href) {
   removeChild(main);

   (async () => {

    const ArrayExperience = await getdata(experiences);
    main.appendChild(Div([], ".experiences"));
    ArrayExperience.forEach(i => CpExperience(Select('.experiences'), i));

   })();
   href = location.href;
  }

 });

 /* ********************************** */
/*
 btnP.addEventListener("click", (event) => {
  history.pushState(null, "", "proyects");
  if(location.href !== href) {
   removeChild(main);

   (async () => {

    const ArrayProyect = await getdata(proyects);
    main.appendChild(Div([], ".proyects"));
    ArrayProyect.forEach(i => CpProyect(Select('.proyects'), i));

   })();
   href = location.href;
  }

 });

 /* ********************************** */
/*
 btnEd.addEventListener("click", (event) => {
  history.pushState(null, "", "educations");
  if(location.href !== href) {
   removeChild(main);

   (async () => {

    const ArrayEducation = await getdata(educations);
    main.appendChild(Div([], ".educations"));
    ArrayEducation.forEach(i => CpEducation(Select('.educations'), i));

   })();
   href = location.href;
  }

 });

 /* ********************************** */
/*
 btnR.addEventListener("click", (event) => {
  history.pushState(null, "", "references");
  if(location.href !== href) {
   removeChild(main);

   (async () => {

    const ArrayReference = await getdata(references);
    main.appendChild(Div([], ".references"));
    ArrayReference.forEach(i => CpReference(Select('.references'), i));

   })();
   href = location.href;
  }

 });
*/
}