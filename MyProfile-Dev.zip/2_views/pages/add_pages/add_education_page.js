import Ui from "../../../3_controllers/helpers/ui.js";
import handleUrl from "../../../3_controllers/helpers/handleUrl.js";
import controller_education from "../../../3_controllers/controller_education.js";

export default function add_education_page() {
   //
   const { Div, Label, Button, Input, Form } = Ui;
   //
   return Div(
      [
         Div(
            [
               Button("back", ".back-btn", null, (e) => {
                  handleUrl.back();
               }),
               Label("Add New Education", ".add-page-tittle-page"),
            ],
            ".add-page-container-back-btn-tittle"
         ),

         Div(
            [
               Div(
                  [
                     Input("", "Tittle", "t", "error", "name", "fild"),
                     Input("", "Institution", "t", "error", "name", "fild"),
                     Input("", "Image Name", "t", "error", "name", "fild"),
                     Div(
                        [
                           Label("More Education", ".add-page-tittle-task"),
                           Div(
                              [
                                 Input(
                                    "",
                                    "Tittle",
                                    "t",
                                    "error",
                                    "name",
                                    "fild"
                                 ),
                                 Input("", "Url", "t", "error", "name", "fild"),
                                 Input(
                                    "",
                                    "Img Name",
                                    "t",
                                    "error",
                                    "name",
                                    "fild"
                                 ),
                              ],
                              ".add-page-more-education"
                           ),
                        ],
                        ".more-education"
                     ),
                  ],
                  ".add-page-filds"
               ),

               Button("Save", ".save-btn", null, (e) =>
                  controller_skill.post(da, ".form-education")
               ),
            ],
            ".add-page-form form-education"
         ),
      ],
      ".add-page-container-page"
   );
}
