import Ui from "../../../3_controllers/helpers/ui.js";
import handleUrl from "../../../3_controllers/helpers/handleUrl.js";
import controller_skill from "../../../3_controllers/controller_skill.js";

export default function add_skill_page(da) {
   //
   const { Div, Label, Button, Input, Form } = Ui;
   //
   return Div(
      [
         Div(
            [
               Button("back", ".back-btn", null, (e) => {
                  handleUrl.back();
               }),
               Label("Add New Skill", ".add-page-tittle-page"),
            ],
            ".add-page-container-back-btn-tittle"
         ),

         Div(
            [
               Div(
                  [
                     Input("", "Name", null, "error", ".name", "fild"),
                     Input("", "Image name", "image", "error", ".name", "fild"),
                  ],
                  ".add-page-filds"
               ),

               Button("Save", ".save-btn add-page-save-btn", null, (e) =>
                  controller_skill.post(da, ".form-skill")
               ),
            ],
            ".add-page-form form-skill"
         ),
      ],
      ".add-page-container-page"
   );
}
