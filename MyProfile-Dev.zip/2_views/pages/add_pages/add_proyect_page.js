import Ui from "../../../3_controllers/helpers/ui.js";
import handleUrl from "../../../3_controllers/helpers/handleUrl.js";
import controller_proyect from "../../../3_controllers/controller_proyect.js";

export default function add_proyect_page() {
   //
   const { Div, Label, Button, Input, Form } = Ui;
   //
   return Div(
      [
         Div(
            [
               Button("back", ".back-btn", null, (e) => {
                  handleUrl.back();
               }),
               Label("Add New Proyect", ".add-page-tittle-page"),
            ],
            ".add-page-container-back-btn-tittle"
         ),

         Div(
            [
               Div(
                  [
                     Input("", "Tittle", "t", "error", "name", "fild"),
                     Input("", "Description", "t", "error", "name", "fild"),

                     Div(
                        [
                           Label("Ternologys", ".add-page-tittle-terno"),
                           Input("", "Name", "t", "error", "name", "fild"),
                        ],
                        ".ternology"
                     ),
                     Div(
                        [
                           Label("Repositorys", ".add-page-tittle-repo"),
                           Input("", "Name", "t", "error", "name", "fild"),
                        ],
                        ".repository"
                     ),
                  ],
                  ".add-page-filds"
               ),

               Button("Save", ".save-btn", null, (e) =>
                  controller_skill.post(da, ".form-proyect")
               ),
            ],
            ".add-page-form form-proyect"
         ),
      ],
      ".add-page-container-page"
   );
}
