import Ui from "../../../3_controllers/helpers/ui.js";
import handleUrl from "../../../3_controllers/helpers/handleUrl.js";
import { Select } from "../../../3_controllers/helpers/tools.js";
import controller_education from "../../../3_controllers/controller_education.js";

export default function add_education_page() {
   //
   const { Div, Label, Button, Input, Form, Line } = Ui;
   let countMoreE = 1;
   //
   return Form([Div(
      [
         Div(
            [
               Button("back", ".back-btn", null, (e) => {
                  handleUrl.back();
               }),
               Label("Add New Education", ".add-page-tittle-page"),
            ],
            ".add-page-container-back-btn-tittle"
         ),

         Div(
            [
               Div(
                  [
                     Input("", "Tittle", "t", "error", "name", "fild"),
                     Input("", "Institution", "t", "error", "name", "fild"),
                     Input("", "Image Name", "t", "error", "name", "fild"),

                     Div(
                        [
                           Div(
                              [
                                 Label(
                                    "More Education",
                                    ".add-page-tittle-task"
                                 ),
                                 Ui.Button(
                                    Ui.Icon("add_circle", "icon-switch"),
                                    ".btn-add-fild",
                                    null,
                                    (e) => {
                                       const divfather =
                                          Select(".more-education");

                                       divfather.appendChild(
                                          Div(
                                             [
                                                Line("divide-more-e"),
                                                Input(
                                                   "",
                                                   "Tittle",
                                                   "t",
                                                   "error",
                                                   `ME-Tittle-${countMoreE}`,
                                                   "fild"
                                                ),
                                                Input(
                                                   "",
                                                   "Url",
                                                   "t",
                                                   "error",
                                                   `ME-Url-${countMoreE}`,
                                                   "fild"
                                                ),
                                                Input(
                                                   "",
                                                   "Img Name",
                                                   "t",
                                                   "error",
                                                   `ME-Img-${countMoreE}`,
                                                   "fild"
                                                ),
                                             ],
                                             ".add-page-more-education"
                                          )
                                       );
                                       countMoreE++;
                                    }
                                 ),
                              ],
                              ".add-btn-header"
                           ),
                           Div(
                              [
                                 Div(
                                    [
                                       Input(
                                          "",
                                          "Tittle",
                                          "t",
                                          "error",
                                          "name",
                                          "fild"
                                       ),
                                       Input(
                                          "",
                                          "Url",
                                          "t",
                                          "error",
                                          "name",
                                          "fild"
                                       ),
                                       Input(
                                          "",
                                          "Img Name",
                                          "t",
                                          "error",
                                          "name",
                                          "fild"
                                       ),
                                    ],
                                    ".add-page-more-education"
                                 ),
                              ],
                              ".more-education add-item-group"
                           ),
                        ],
                        ".more-education-group"
                     ),
                  ],
                  ".add-page-filds"
               ),

               Button("Save", ".save-btn", null, (e) =>
                  controller_education.post(da, document.forms[0])
               ),
            ],
            ".add-page-form form-education"
         ),
      ],
      ".add-page-container-page"
   )])
}
