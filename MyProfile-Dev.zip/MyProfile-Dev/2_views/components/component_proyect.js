import Ui from "../../3_controllers/helpers/ui.js";

export default function cp_proyect( {tittle,description,tegnologys,repositorys}) {
   const { Div, Label, Link } = Ui;

   const labelT = Label(tittle, ".proyect-tittle");
   const labelD = Label(description, ".proyect-description");
   const divCT = Div(
      [Label("Tegnologias", ".proyect-titleTegnology")],
      ".proyect-container-tegnology-base"
   );

   const divT = Div(
      [],
      ".proyect-container-tegnology",
      `border:1px solid silver;`
   );

   const divR = Div(
      [],
      ".proyect-container-repository",
      `border:1px solid silver;`
   );

   tegnologys.forEach((element) => {
      divT.appendChild(Label(element, ".proyect-tenology"));
   });

   divCT.appendChild(divT);

   repositorys.forEach((element) => {
      divR.appendChild(Link(element, element, ".proyect-repository", ""));
   });

/*   const styles = `
         border-width: 2px;
         border-style: double;
         border-bottom-color: ${P};
         border-left-color: ${P};
         border-top-color: ${T};
         border-right-color: ${T};`;*/

   
     return repositorys[0] === undefined
         ? Div([labelT, labelD, divCT], ".proyect-constainer-experience")
         : Div([labelT, labelD, divCT, divR], ".proyect-constainer-experience");

}
