import Ui from "../../3_controllers/helpers/ui.js";

export default function cp_reference({name,phone_number}) {
   const { Div, Label } = Ui;

   return Div([Label(name, ".name"), Label(phone_number, ".phone")], ".constainer-reference",
        /* `
         border-width: 2px;
         border-style: double;
         border-bottom-color: ${P};
         border-left-color: ${P};
         border-top-color: ${T};
         border-right-color: ${T};`*/);
}
