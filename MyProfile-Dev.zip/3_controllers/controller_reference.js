import add_reference_page from "../../2_views/pages/add_pages/add_reference_page.js";
import view_reference_page from "../../2_views/pages/view_pages/view_reference_page.js";
//
import { references } from "../1_models/models.js";

export default class controller_reference {
   static add(da) {
      return add_reference_page(da);
   }
   static view(da) {
     return (async () => {
         return view_reference_page(await da(references),da);
      })();
   }
   static post(da, form) {
      alert("data save");
   }
   static delete(da, value) {
      alert("data delete");
      console.log(value);
      this.view(da);
   }
}
