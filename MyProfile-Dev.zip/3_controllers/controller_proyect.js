import add_proyect_page from "../../2_views/pages/add_pages/add_proyect_page.js";
import view_proyect_page from "../../2_views/pages/view_pages/view_proyect_page.js";
//
import { proyects } from "../1_models/models.js";

export default class controller_proyect {
   static add(da) {
      return add_proyect_page(da);
   }
   static view(da) {
      return (async () => {
         return view_proyect_page(await da(proyects), da);
      })();
   }
   static post(da, form) {
      alert("data save");
   }
   static delete(da, value) {
      alert("data delete");
      console.log(value);
      this.view(da);
   }
}
