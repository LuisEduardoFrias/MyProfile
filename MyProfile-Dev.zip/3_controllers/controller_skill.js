import add_skill_page from "../2_views/pages/add_pages/add_skill_page.js";
import view_skill_page from "../2_views/pages/view_pages/view_skill_page.js";
//
import { skills } from "../1_models/models.js";

export default class controller_skill {
   static add(da) {
      return add_skill_page(da);
   }
   static view(da) {
      return (async () => {
         return view_skill_page(await da(skills), da);
      })();
   }
   static post(da, form) {
      alert("data save");
   }
   static delete(da, value) {
      alert("data delete");
      console.log(value);
      this.view(da);
   }
}
