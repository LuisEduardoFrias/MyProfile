import add_experience_page from "../../2_views/pages/add_pages/add_experience_page.js";
import view_experience_page from "../../2_views/pages/view_pages/view_experience_page.js";
//
import { experiences } from "../1_models/models.js";

export default class controller_experience {
   static add(da) {
      return add_experience_page(da);
   }
   static view(da) {
     return  (async () => {
         return view_experience_page(await da(experiences),da);
      })();
   }
   static post(da, form) {
      alert("data save");
   }
   static delete(da, value) {
      alert("data delete");
      console.log(value);
      this.view(da);
   }
}
