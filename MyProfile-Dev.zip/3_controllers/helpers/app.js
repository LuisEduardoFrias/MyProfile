import handleUrl from "./handleUrl.js";

handleUrl.listenerUrl();
