import add_education_page from "../../2_views/pages/add_pages/add_education_page.js";
import view_education_page from "../../2_views/pages/view_pages/view_education_page.js";
//
import { educations } from "../1_models/models.js";

export default class controller_education {
   static add(da) {
      return add_education_page(da);
   }
   static view(da) {
     return (async () => {
         return view_education_page(await da(educations),da);
      })();
   }
   static post(da, form) {
      alert("data save");
   }
   static delete(da, value) {
      alert("data delete");
      console.log(value);
      this.view(da);
   }
}
